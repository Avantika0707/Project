// marketplace.js - products, search, filter, sort, favourites, add listing
var categories = ["Uniforms and clothing","Textbooks","Stationery and notebooks","Lab coats and equipment","Test tubes and slides","BCA/BTech books","Engineering tools","BBA/MBA materials","Law books","MBBS resources","BPharma materials","Calculators and electronics","Competitive exam books","Other"];

// Each product is an object inside an array
var products = [
  {name:"Data Structures in C", category:"BCA/BTech books", price:350, condition:"Like New", seller:"Aarav", id:"AX-1001", image:"books"},
  {name:"College Blazer (M)", category:"Uniforms and clothing", price:900, condition:"Used", seller:"Meera", id:"AX-1002", image:"uniforms"},
  {name:"Lab Coat (L)", category:"Lab coats and equipment", price:450, condition:"Like New", seller:"Rohan", id:"AX-1003", image:"lab-equipment"},
  {name:"Notebook Pack (6)", category:"Stationery and notebooks", price:180, condition:"New", seller:"Sneha", id:"AX-1004", image:"stationery"},
  {name:"Test Tube Set", category:"Test tubes and slides", price:260, condition:"New", seller:"Kabir", id:"AX-1005", image:"lab-equipment"},
  {name:"Constitution of India", category:"Law books", price:520, condition:"Used", seller:"Ishita", id:"AX-1006", image:"books"},
  {name:"Scientific Calculator", category:"Calculators and electronics", price:700, condition:"Like New", seller:"Dev", id:"AX-1007", image:"stationery"},
  {name:"Marketing Notes", category:"BBA/MBA materials", price:150, condition:"Used", seller:"Pooja", id:"AX-1008", image:"books"},
  {name:"Anatomy Guide", category:"MBBS resources", price:600, condition:"Like New", seller:"Rohan", id:"AX-1003", image:"books"},
  {name:"Pharmacology Notes", category:"BPharma materials", price:240, condition:"Used", seller:"Kabir", id:"AX-1005", image:"books"},
  {name:"Arduino Kit", category:"Engineering tools", price:1200, condition:"New", seller:"Dev", id:"AX-1007", image:"lab-equipment"},
  {name:"Aptitude Book", category:"Competitive exam books", price:300, condition:"Used", seller:"Aarav", id:"AX-1001", image:"books"}
];
var favourites = [];  // names of saved products

// Fill the category drop-downs
function fillCategories(){
  var list = '<option value="">All categories</option>';
  var list2 = '';
  for (var i = 0; i < categories.length; i++){
    list += '<option>' + categories[i] + '</option>';
    list2 += '<option>' + categories[i] + '</option>';
  }
  document.getElementById('category').innerHTML = list;
  document.getElementById('newCategory').innerHTML = list2;
}

// Search + filter + sort, then draw the cards
function showProducts(){
  var text = document.getElementById('search').value.toLowerCase();
  var cat = document.getElementById('category').value;
  var sort = document.getElementById('sort').value;
  var result = [];
  for (var i = 0; i < products.length; i++){
    var p = products[i];
    var nameMatch = p.name.toLowerCase().indexOf(text) !== -1;
    var catMatch = (cat === '' || p.category === cat);
    if (nameMatch && catMatch){ result.push(p); }
  }
  if (sort === 'low'){ result.sort(function(a,b){ return a.price - b.price; }); }
  if (sort === 'high'){ result.sort(function(a,b){ return b.price - a.price; }); }

  var html = '';
  for (var j = 0; j < result.length; j++){
    var item = result[j];
    var saved = favourites.indexOf(item.name) !== -1;
    html += '<div class="card"><img src="assets/images/' + item.image + '.svg" alt="' + item.name + '">' +
      '<h3>' + item.name + '</h3><p>Rs ' + item.price + ' | ' + item.condition + '</p>' +
      '<p>' + item.category + '</p><p>Seller: ' + item.seller + ' (' + item.id + ')</p>' +
      '<button onclick="viewProduct(\'' + item.name + '\')">View Details</button> ' +
      '<button onclick="toggleFavourite(\'' + item.name + '\')">' + (saved ? 'Saved' : 'Save') + '</button></div>';
  }
  if (html === ''){ html = '<p>No products found. Try another search.</p>'; }
  document.getElementById('products').innerHTML = html;
}

function clearFilters(){
  document.getElementById('search').value = '';
  document.getElementById('category').value = '';
  document.getElementById('sort').value = '';
  showProducts();
}

function viewProduct(name){
  for (var i = 0; i < products.length; i++){
    if (products[i].name === name){
      var p = products[i];
      alert(p.name + '\nPrice: Rs ' + p.price + '\nCondition: ' + p.condition + '\nSeller: ' + p.seller + ' (' + p.id + ')');
      if (confirm('Are you interested in buying? (simulated, no payment)')){
        alert('Request recorded for demo only. Nothing was sent to ' + p.seller + '.');
      }
    }
  }
}

function toggleFavourite(name){
  var pos = favourites.indexOf(name);
  if (pos === -1){ favourites.push(name); } else { favourites.splice(pos, 1); }
  showProducts();
}

// Add a new product after checking the form
function addProduct(){
  var name = document.getElementById('newName').value.trim();
  var price = Number(document.getElementById('newPrice').value);
  var seller = document.getElementById('newSeller').value.trim();
  var msg = document.getElementById('formMessage');
  if (name === '' || seller === '' || price <= 0){
    msg.className = 'error';
    msg.innerHTML = 'Please fill the name, a price above 0, and the seller name.';
    return;
  }
  products.push({name:name, category:document.getElementById('newCategory').value, price:price,
    condition:document.getElementById('newCondition').value, seller:seller, id:'AX-0000', image:'books'});
  msg.className = 'ok';
  msg.innerHTML = 'Listing added! (It will disappear when you refresh the page.)';
  showProducts();
}

fillCategories();
showProducts();
